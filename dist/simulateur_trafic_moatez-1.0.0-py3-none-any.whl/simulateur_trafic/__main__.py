"""
Point d'entrée pour python -m simulateur_trafic
"""

from .main import main

if __name__ == "__main__":
    main()